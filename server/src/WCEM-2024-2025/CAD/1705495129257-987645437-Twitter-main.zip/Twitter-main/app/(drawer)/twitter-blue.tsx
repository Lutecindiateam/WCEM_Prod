import { View, Text } from 'react-native';

const TwitterBlue = () => {
  return (
    <View>
      <Text>twitter-blue</Text>
    </View>
  );
};

export default TwitterBlue;
