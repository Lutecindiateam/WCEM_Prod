import { View, Text } from 'react-native';

const Bookmarks = () => {
  return (
    <View>
      <Text>bookmarks</Text>
    </View>
  );
};

export default Bookmarks;
