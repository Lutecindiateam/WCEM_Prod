import 'react-native-gesture-handler';
import 'expo-router/entry';
